"""
Header/Navigation tests.

Tests for:
- Header navigation links
- Logo click functionality
- Navigation to different sections
"""

import allure
import pytest
from pages.header import Header
from pages.footer import Footer


@allure.feature("Header")
@allure.story("Navigation Links")
class TestHeader:
    """Test suite for header navigation."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.header = Header(page)
        self.page = page
        self.header.open()

    @allure.title("Verify About link in header")
    @allure.description("Test that About link exists and is visible in header")
    def test_about_link_visible(self):
        """Test that About link is visible in the header."""
        with allure.step("Verify About link exists"):
            self.header.verify_about_link_exists()

    @allure.title("Verify Services link in header")
    @allure.description("Test that Services link exists and is visible in header")
    def test_services_link_visible(self):
        """Test that Services link is visible in the header."""
        with allure.step("Verify Services link exists"):
            self.header.verify_services_link_exists()

    @allure.title("Verify Contacts link in header")
    @allure.description("Test that Contacts link exists and is visible in header")
    def test_contacts_link_visible(self):
        """Test that Contacts link is visible in the header."""
        with allure.step("Verify Contacts link exists"):
            self.header.verify_contacts_link_exists()

    @allure.title("Verify Careers link in header")
    @allure.description("Test that Careers link exists and is visible in header")
    def test_careers_link_visible(self):
        """Test that Careers link is visible in the header."""
        with allure.step("Verify Careers link exists"):
            self.header.verify_careers_link_exists()

    @allure.title("Click on About link")
    @allure.description("Test clicking on About link in header")
    def test_click_about_link(self):
        """Test clicking on About link navigates correctly."""
        with allure.step("Click About link"):
            self.header.click_about_link()
        
        with allure.step("Verify page scrolled to About section"):
            self.page.wait_for_timeout(1000)
            current_url = self.header.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Services link")
    @allure.description("Test clicking on Services link in header")
    def test_click_services_link(self):
        """Test clicking on Services link navigates correctly."""
        with allure.step("Click Services link"):
            self.header.click_services_link()
        
        with allure.step("Verify page scrolled to Services section"):
            self.page.wait_for_timeout(1000)
            current_url = self.header.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Contacts link")
    @allure.description("Test clicking on Contacts link in header")
    def test_click_contacts_link(self):
        """Test clicking on Contacts link navigates correctly."""
        with allure.step("Click Contacts link"):
            self.header.click_contacts_link()
        
        with allure.step("Verify page scrolled to Contacts section"):
            self.page.wait_for_timeout(1000)
            current_url = self.header.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Vacancies/Careers link opens AI Hunt")
    @allure.description("Test that Vacancies link opens AI Hunt website in new tab")
    def test_click_vacancies_link(self):
        """Test clicking on Vacancies link opens correct URL."""
        with allure.step("Click Vacancies link"):
            new_page = self.header.click_vacancies_link()
        
        with allure.step("Verify new page opened with AI Hunt URL"):
            assert new_page is not None
            new_page.wait_for_load_state()
            assert "ai-hunt.ru" in new_page.url
            new_page.close()

    @allure.title("Click on logo returns to home")
    @allure.description("Test that clicking logo returns to home page")
    def test_click_logo_returns_home(self):
        """Test clicking logo returns to home page."""
        with allure.step("Click Services link first"):
            self.header.click_services_link()
            self.page.wait_for_timeout(500)
        
        with allure.step("Click logo"):
            self.header.click_logo()
        
        with allure.step("Verify returned to home"):
            self.page.wait_for_timeout(500)
            current_url = self.header.get_current_url()
            assert "effective-mobile.ru" in current_url
