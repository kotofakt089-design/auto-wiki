"""
Footer tests.

Tests for:
- Footer links
- Social media links
- Contact information
"""

import allure
import pytest
from pages.footer import Footer


@allure.feature("Footer")
@allure.story("Footer Links and Contacts")
class TestFooter:
    """Test suite for footer elements and links."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.footer = Footer(page)
        self.page = page
        self.footer.open()

    @allure.title("Verify email link in footer")
    @allure.description("Test that email link is visible in footer")
    def test_email_link_visible(self):
        """Test that email link is visible in the footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Verify email link exists"):
            self.footer.verify_email_link()

    @allure.title("Verify Telegram link in footer")
    @allure.description("Test that Telegram link is visible in footer")
    def test_telegram_link_visible(self):
        """Test that Telegram link is visible in the footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Verify Telegram link exists"):
            self.footer.verify_telegram_link()

    @allure.title("Click on About Us link in footer")
    @allure.description("Test clicking About Us link in footer")
    def test_click_about_us_footer(self):
        """Test clicking About Us link in footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click About Us link"):
            self.footer.click_about_us_footer()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Vacancies link in footer")
    @allure.description("Test clicking Vacancies link in footer")
    def test_click_vacancies_footer(self):
        """Test clicking Vacancies link in footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Vacancies link"):
            new_page = self.footer.VACANCIES_FOOTER()
            self.page.wait_for_load_state()

    @allure.title("Click on Outstaffing link in footer")
    @allure.description("Test clicking Outstaffing link in footer")
    def test_click_outstaffing_footer(self):
        """Test clicking Outstaffing link in footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Outstaffing link"):
            self.footer.click_outstaffing_footer()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Employment link in footer")
    @allure.description("Test clicking Employment link in footer")
    def test_click_employment_footer(self):
        """Test clicking Employment link in footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Employment link"):
            self.footer.click_employment_footer()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Consultation link in footer")
    @allure.description("Test clicking Consultation link in footer")
    def test_click_consultation_footer(self):
        """Test clicking Consultation link in footer."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Consultation link"):
            self.footer.click_consultation_footer()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Privacy Policy link")
    @allure.description("Test clicking Privacy Policy link")
    def test_click_privacy_policy(self):
        """Test clicking Privacy Policy link."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Privacy Policy link"):
            self.footer.click_privacy_policy()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click on Terms of Use link")
    @allure.description("Test clicking Terms of Use link")
    def test_click_terms_of_use(self):
        """Test clicking Terms of Use link."""
        with allure.step("Scroll to footer"):
            self.footer.scroll_to_footer()
        
        with allure.step("Click Terms of Use link"):
            self.footer.click_terms_of_use()
        
        with allure.step("Verify page navigated correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.footer.get_current_url()
            assert "effective-mobile.ru" in current_url
