"""
Base Page Object containing common methods for all pages.
"""

import allure
from playwright.sync_api import Page, expect


class BasePage:
    """Base page class with common methods for all page objects."""

    BASE_URL = "https://www.effective-mobile.ru/"

    def __init__(self, page: Page):
        """Initialize the page.
        
        Args:
            page: Playwright page instance
        """
        self.page = page

    @allure.step("Open URL: {url}")
    def open(self, url: str = None):
        """Navigate to the specified URL or base URL.
        
        Args:
            url: Optional URL to navigate to. If None, uses BASE_URL
        """
        target_url = url or self.BASE_URL
        self.page.goto(target_url, wait_until="domcontentloaded")

    @allure.step("Wait for URL to be: {expected_url}")
    def wait_for_url(self, expected_url: str, timeout: int = 10000):
        """Wait for the page URL to match the expected URL.
        
        Args:
            expected_url: Expected URL pattern
            timeout: Timeout in milliseconds
        """
        self.page.wait_for_url(expected_url, timeout=timeout)

    @allure.step("Click on element: {locator}")
    def click(self, locator):
        """Click on an element.
        
        Args:
            locator: Playwright locator object or selector string
        """
        if isinstance(locator, str):
            self.page.locator(locator).click()
        else:
            locator.click()

    @allure.step("Fill text field: {locator} with text: {text}")
    def fill(self, locator, text: str):
        """Fill a text field with the provided text.
        
        Args:
            locator: Playwright locator object or selector string
            text: Text to fill
        """
        if isinstance(locator, str):
            self.page.locator(locator).fill(text)
        else:
            locator.fill(text)

    @allure.step("Get text from element: {locator}")
    def get_text(self, locator):
        """Get text from an element.
        
        Args:
            locator: Playwright locator object or selector string
            
        Returns:
            Text content of the element
        """
        if isinstance(locator, str):
            return self.page.locator(locator).text_content()
        return locator.text_content()

    @allure.step("Assert element is visible: {locator}")
    def assert_element_visible(self, locator):
        """Assert that an element is visible.
        
        Args:
            locator: Playwright locator object or selector string
        """
        if isinstance(locator, str):
            expect(self.page.locator(locator)).to_be_visible()
        else:
            expect(locator).to_be_visible()

    @allure.step("Assert element is not visible: {locator}")
    def assert_element_not_visible(self, locator):
        """Assert that an element is not visible.
        
        Args:
            locator: Playwright locator object or selector string
        """
        if isinstance(locator, str):
            expect(self.page.locator(locator)).not_to_be_visible()
        else:
            expect(locator).not_to_be_visible()

    @allure.step("Wait for element to load: {locator}")
    def wait_for_element(self, locator, timeout: int = 10000):
        """Wait for an element to be visible.
        
        Args:
            locator: Playwright locator object or selector string
            timeout: Timeout in milliseconds
        """
        if isinstance(locator, str):
            self.page.locator(locator).wait_for(timeout=timeout)
        else:
            locator.wait_for(timeout=timeout)

    @allure.step("Get current URL")
    def get_current_url(self) -> str:
        """Get the current page URL.
        
        Returns:
            Current page URL
        """
        return self.page.url

    @allure.step("Scroll to element: {locator}")
    def scroll_to_element(self, locator):
        """Scroll to an element.
        
        Args:
            locator: Playwright locator object or selector string
        """
        if isinstance(locator, str):
            self.page.locator(locator).scroll_into_view_if_needed()
        else:
            locator.scroll_into_view_if_needed()

    @allure.step("Scroll to bottom of page")
    def scroll_to_bottom(self):
        """Scroll to the bottom of the page."""
        self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        self.page.wait_for_timeout(500)

    @allure.step("Assert URL contains: {expected_url}")
    def assert_url_contains(self, expected_url: str):
        """Assert that the current URL contains the expected string.
        
        Args:
            expected_url: Expected URL substring
        """
        expect(self.page).to_have_url(f"**{expected_url}**")

    @allure.step("Take screenshot: {name}")
    def take_screenshot(self, name: str):
        """Take a screenshot of the page.
        
        Args:
            name: Name for the screenshot file
        """
        self.page.screenshot(path=f"screenshots/{name}.png")

    @allure.step("Accept new page context")
    def handle_popup_page(self):
        """Wait and handle a popup/new page.
        
        Returns:
            New page instance
        """
        with self.page.context.expect_page() as new_page_info:
            pass
        return new_page_info.value
