"""
Header/Navigation Page Object.
"""

import allure
from pages.base_page import BasePage


class Header(BasePage):
    """Header/Navigation page object containing all header elements and interactions."""

    # Locators for header elements (footer links with anchor navigation)
    LOGO = lambda self: self.page.get_by_role("link", name="EM").first
    ABOUT_LINK = lambda self: self.page.locator("footer").get_by_role("link", name="О нас").first
    SERVICES_LINK = lambda self: self.page.locator("footer").get_by_role("link", name="Аутстафф")
    CONTACTS_LINK = lambda self: self.page.locator("footer").get_by_role("link", name="Контакты")
    CAREERS_LINK = lambda self: self.page.locator("footer").get_by_role("link", name="Вакансии")
    VACANCIES_LINK = lambda self: self.page.get_by_role("link", name="Актуальные вакансии").first

    @allure.step("Click on About link in footer")
    def click_about_link(self):
        """Click on 'О нас' (About) link in the footer."""
        self.scroll_to_bottom()
        self.click(self.ABOUT_LINK())

    @allure.step("Click on Services link in footer")
    def click_services_link(self):
        """Click on 'Аутстафф' (Services/Outstaffing) link in the footer."""
        self.scroll_to_bottom()
        self.click(self.SERVICES_LINK())

    @allure.step("Click on Contacts link in footer")
    def click_contacts_link(self):
        """Click on 'Контакты' (Contacts) link in the footer."""
        self.scroll_to_bottom()
        self.click(self.CONTACTS_LINK())

    @allure.step("Click on Careers/Vacancies link in footer")
    def click_careers_link(self):
        """Click on 'Вакансии' (Careers) link in the footer."""
        self.scroll_to_bottom()
        self.click(self.CAREERS_LINK())

    @allure.step("Click on vacancies link")
    def click_vacancies_link(self):
        """Click on 'Актуальные вакансии' (Current vacancies) link."""
        with self.page.context.expect_page() as new_page_info:
            self.click(self.VACANCIES_LINK())
        return new_page_info.value

    @allure.step("Click on logo in header")
    def click_logo(self):
        """Click on the logo to return to home page."""
        self.click(self.LOGO())

    @allure.step("Verify About link exists")
    def verify_about_link_exists(self):
        """Verify that About link is visible in footer."""
        self.scroll_to_bottom()
        self.assert_element_visible(self.ABOUT_LINK())

    @allure.step("Verify Services link exists")
    def verify_services_link_exists(self):
        """Verify that Services link is visible in footer."""
        self.scroll_to_bottom()
        self.assert_element_visible(self.SERVICES_LINK())

    @allure.step("Verify Contacts link exists")
    def verify_contacts_link_exists(self):
        """Verify that Contacts link is visible in footer."""
        self.scroll_to_bottom()
        self.assert_element_visible(self.CONTACTS_LINK())

    @allure.step("Verify Careers link exists")
    def verify_careers_link_exists(self):
        """Verify that Careers link is visible in footer."""
        self.scroll_to_bottom()
        self.assert_element_visible(self.CAREERS_LINK())
