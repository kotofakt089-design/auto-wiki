"""
Footer Page Object.
"""

import allure
from pages.base_page import BasePage


class Footer(BasePage):
    """Footer page object containing all footer elements and interactions."""

    # Locators for footer elements
    EMAIL_LINK = lambda self: self.page.locator("footer").locator("text=hrdepartment@effmobile.ru")
    TELEGRAM_LINK = lambda self: self.page.locator("footer").locator("text=@assistant_em")
    ABOUT_US_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="О нас").first
    VACANCIES_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Вакансии").first
    REVIEWS_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Отзывы").first
    CONTACTS_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Контакты").first
    OUTSTAFFING_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Аутстафф")
    EMPLOYMENT_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Трудоустройство")
    CONSULTATION_FOOTER = lambda self: self.page.locator("footer").get_by_role("link", name="Консультация")
    PRIVACY_POLICY = lambda self: self.page.get_by_role("link", name="Политика конфиденциальности").last
    TERMS_OF_USE = lambda self: self.page.get_by_role("link", name="Условия использования").last

    @allure.step("Verify email link in footer")
    def verify_email_link(self):
        """Verify that email link is visible in footer."""
        self.scroll_to_footer()
        self.assert_element_visible(self.EMAIL_LINK())

    @allure.step("Verify telegram link in footer")
    def verify_telegram_link(self):
        """Verify that Telegram link is visible in footer."""
        self.scroll_to_footer()
        self.assert_element_visible(self.TELEGRAM_LINK())

    @allure.step("Click on About Us link in footer")
    def click_about_us_footer(self):
        """Click on 'О нас' (About Us) link in footer."""
        self.scroll_to_footer()
        self.click(self.ABOUT_US_FOOTER())

    @allure.step("Click on Vacancies link in footer")
    def click_vacancies_footer(self):
        """Click on 'Вакансии' (Vacancies) link in footer."""
        self.scroll_to_footer()
        self.click(self.VACANCIES_FOOTER())

    @allure.step("Click on Reviews link in footer")
    def click_reviews_footer(self):
        """Click on 'Отзывы' (Reviews) link in footer."""
        self.scroll_to_footer()
        self.click(self.REVIEWS_FOOTER())

    @allure.step("Click on Contacts link in footer")
    def click_contacts_footer(self):
        """Click on 'Контакты' (Contacts) link in footer."""
        self.scroll_to_footer()
        self.click(self.CONTACTS_FOOTER())

    @allure.step("Click on Outstaffing link in footer")
    def click_outstaffing_footer(self):
        """Click on 'Аутстафф' (Outstaffing) link in footer."""
        self.scroll_to_footer()
        self.click(self.OUTSTAFFING_FOOTER())

    @allure.step("Click on Employment link in footer")
    def click_employment_footer(self):
        """Click on 'Трудоустройство' (Employment) link in footer."""
        self.scroll_to_footer()
        self.click(self.EMPLOYMENT_FOOTER())

    @allure.step("Click on Consultation link in footer")
    def click_consultation_footer(self):
        """Click on 'Консультация' (Consultation) link in footer."""
        self.scroll_to_footer()
        self.click(self.CONSULTATION_FOOTER())

    @allure.step("Click on Privacy Policy link")
    def click_privacy_policy(self):
        """Click on Privacy Policy link."""
        self.scroll_to_footer()
        self.click(self.PRIVACY_POLICY())

    @allure.step("Click on Terms of Use link")
    def click_terms_of_use(self):
        """Click on Terms of Use link."""
        self.scroll_to_footer()
        self.click(self.TERMS_OF_USE())

    @allure.step("Scroll to footer")
    def scroll_to_footer(self):
        """Scroll to footer section."""
        self.scroll_to_element(self.EMAIL_LINK())
