"""
UI tests initialization.
"""
