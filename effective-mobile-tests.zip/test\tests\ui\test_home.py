"""
Home page tests.

Tests for:
- Main page sections visibility
- CTA buttons functionality
- Contact form
- Specialist categories
- Process steps
"""

import allure
import pytest
from pages.home_page import HomePage


@allure.feature("Home Page")
@allure.story("Page Sections")
class TestHomePageSections:
    """Test suite for home page sections visibility."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.home = HomePage(page)
        self.page = page
        self.home.open_home_page()

    @allure.title("Verify About Company section is visible")
    @allure.description("Test that About Company section loads correctly")
    def test_about_company_section_visible(self):
        """Test that About Company section is visible."""
        with allure.step("Verify About Company section"):
            self.home.verify_about_company_visible()

    @allure.title("Verify Cooperation Formats section is visible")
    @allure.description("Test that Cooperation Formats section loads correctly")
    def test_cooperation_formats_section_visible(self):
        """Test that Cooperation Formats section is visible."""
        with allure.step("Verify Cooperation Formats section"):
            self.home.verify_cooperation_formats_visible()

    @allure.title("Verify Who We Seek section is visible")
    @allure.description("Test that Who We Seek section loads correctly")
    def test_who_we_seek_section_visible(self):
        """Test that Who We Seek section is visible."""
        with allure.step("Verify Who We Seek section"):
            self.home.verify_who_we_seek_visible()

    @allure.title("Verify How It Works section is visible")
    @allure.description("Test that How It Works section loads correctly")
    def test_how_it_works_section_visible(self):
        """Test that How It Works section is visible."""
        with allure.step("Verify How It Works section"):
            self.home.verify_how_it_works_visible()

    @allure.title("Verify Why Choose Us section is visible")
    @allure.description("Test that Why Choose Us section loads correctly")
    def test_why_choose_us_section_visible(self):
        """Test that Why Choose Us section is visible."""
        with allure.step("Verify Why Choose Us section"):
            self.home.verify_why_choose_us_visible()

    @allure.title("Verify Reviews section is visible")
    @allure.description("Test that Reviews section loads correctly")
    def test_reviews_section_visible(self):
        """Test that Reviews section is visible."""
        with allure.step("Verify Reviews section"):
            self.home.verify_reviews_visible()

    @allure.title("Verify Contact Us section is visible")
    @allure.description("Test that Contact Us section loads correctly")
    def test_contact_us_section_visible(self):
        """Test that Contact Us section is visible."""
        with allure.step("Verify Contact Us section"):
            self.home.verify_contact_us_visible()


@allure.feature("Home Page")
@allure.story("Specialist Categories")
class TestSpecialistCategories:
    """Test suite for specialist categories visibility."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.home = HomePage(page)
        self.page = page
        self.home.open_home_page()

    @allure.title("Verify iOS Developer category is visible")
    @allure.description("Test that iOS Developer category is visible")
    def test_ios_developer_visible(self):
        """Test that iOS Developer category is visible."""
        with allure.step("Verify iOS Developer category"):
            self.home.verify_ios_developer_visible()

    @allure.title("Verify Android Developer category is visible")
    @allure.description("Test that Android Developer category is visible")
    def test_android_developer_visible(self):
        """Test that Android Developer category is visible."""
        with allure.step("Verify Android Developer category"):
            self.home.verify_android_developer_visible()

    @allure.title("Verify Backend Developer category is visible")
    @allure.description("Test that Backend Developer category is visible")
    def test_backend_developer_visible(self):
        """Test that Backend Developer category is visible."""
        with allure.step("Verify Backend Developer category"):
            self.home.verify_backend_developer_visible()

    @allure.title("Verify QA Engineer category is visible")
    @allure.description("Test that QA Engineer category is visible")
    def test_qa_engineer_visible(self):
        """Test that QA Engineer category is visible."""
        with allure.step("Verify QA Engineer category"):
            self.home.verify_qa_engineer_visible()

    @allure.title("Verify DevOps Engineer category is visible")
    @allure.description("Test that DevOps Engineer category is visible")
    def test_devops_engineer_visible(self):
        """Test that DevOps Engineer category is visible."""
        with allure.step("Verify DevOps Engineer category"):
            self.home.verify_devops_engineer_visible()

    @allure.title("Verify Analyst category is visible")
    @allure.description("Test that Analyst category is visible")
    def test_analyst_visible(self):
        """Test that Analyst category is visible."""
        with allure.step("Verify Analyst category"):
            self.home.verify_analyst_visible()


@allure.feature("Home Page")
@allure.story("Process Steps")
class TestProcessSteps:
    """Test suite for process steps."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.home = HomePage(page)
        self.page = page
        self.home.open_home_page()

    @allure.title("Verify all process steps are visible")
    @allure.description("Test that all 4 process steps are visible")
    def test_all_process_steps_visible(self):
        """Test that all process steps are visible."""
        with allure.step("Verify all process steps"):
            self.home.verify_all_process_steps_visible()


@allure.feature("Home Page")
@allure.story("CTA Buttons")
class TestCTAButtons:
    """Test suite for CTA buttons."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.home = HomePage(page)
        self.page = page
        self.home.open_home_page()

    @allure.title("Click Leave Application button")
    @allure.description("Test clicking Leave Application button")
    def test_click_leave_application_button(self):
        """Test clicking Leave Application button."""
        with allure.step("Click Leave Application button"):
            self.home.click_leave_application_button()
        
        with allure.step("Verify page state after click"):
            current_url = self.home.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click Learn More button")
    @allure.description("Test clicking Learn More button")
    def test_click_learn_more_button(self):
        """Test clicking Learn More button."""
        with allure.step("Click Learn More button"):
            self.home.click_learn_more_button()
        
        with allure.step("Verify page scrolled correctly"):
            self.page.wait_for_timeout(500)
            current_url = self.home.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Click Current Vacancies button opens new tab")
    @allure.description("Test that Current Vacancies button opens AI Hunt in new tab")
    def test_click_current_vacancies_button(self):
        """Test clicking Current Vacancies button opens AI Hunt."""
        with allure.step("Click Current Vacancies button"):
            new_page = self.home.click_current_vacancies_button()
        
        with allure.step("Verify new page opened with AI Hunt URL"):
            assert new_page is not None
            new_page.wait_for_load_state()
            assert "ai-hunt.ru" in new_page.url
            new_page.close()


@allure.feature("Home Page")
@allure.story("Contact Form")
class TestContactForm:
    """Test suite for contact form."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup for each test.
        
        Args:
            page: Playwright page instance
        """
        self.home = HomePage(page)
        self.page = page
        self.home.open_home_page()

    @allure.title("Fill contact form with required fields")
    @allure.description("Test filling contact form with name and email")
    def test_fill_contact_form_required_fields(self):
        """Test filling contact form with required fields."""
        with allure.step("Fill contact form"):
            self.home.fill_contact_form(
                name="Test User",
                email="test@example.com"
            )
        
        with allure.step("Verify form is filled"):
            current_url = self.home.get_current_url()
            assert "effective-mobile.ru" in current_url

    @allure.title("Fill contact form with all fields")
    @allure.description("Test filling contact form with all available fields")
    def test_fill_contact_form_all_fields(self):
        """Test filling contact form with all fields."""
        with allure.step("Fill contact form with all data"):
            self.home.fill_contact_form(
                name="Test User",
                email="test@example.com",
                phone="+7 (999) 999-99-99",
                specialization="Python Developer",
                message="Test message for automation"
            )
        
        with allure.step("Verify form is filled"):
            current_url = self.home.get_current_url()
            assert "effective-mobile.ru" in current_url
