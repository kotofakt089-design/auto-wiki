"""
Pytest configuration and fixtures.
"""

import pytest
import os
import allure
from playwright.sync_api import sync_playwright, Browser, BrowserContext, Page


HEADLESS_MODE = os.getenv("HEADLESS", "true").lower() == "true"


@pytest.fixture(scope="session")
def browser() -> Browser:
    """Create and yield a browser instance for the session.
    
    Yields:
        Browser instance
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS_MODE)
        yield browser
        browser.close()


@pytest.fixture
def context(browser: Browser) -> BrowserContext:
    """Create and yield a browser context for each test.
    
    Args:
        browser: Browser instance
        
    Yields:
        Browser context
    """
    context = browser.new_context()
    yield context
    context.close()


@pytest.fixture
def page(context: BrowserContext) -> Page:
    """Create and yield a page instance for each test.
    
    Args:
        context: Browser context
        
    Yields:
        Page instance
    """
    page = context.new_page()
    yield page
    page.close()


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Make test result available to fixtures.
    
    Args:
        item: Test item
        call: Test call
    """
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)


@pytest.fixture(autouse=True)
def attach_screenshot_on_failure(page: Page, request):
    """Automatically attach screenshot on test failure.
    
    Args:
        page: Page instance
        request: Pytest request object
    """
    yield
    
    # Check if test failed
    if hasattr(request.node, "rep_call") and request.node.rep_call.failed:
        try:
            screenshot = page.screenshot()
            allure.attach(
                screenshot,
                name="failure_screenshot.png",
                attachment_type=allure.attachment_type.PNG
            )
        except Exception:
            pass
        
        # Attach page HTML
        try:
            html = page.content()
            allure.attach(
                html,
                name="page_html.html",
                attachment_type=allure.attachment_type.HTML
            )
        except Exception:
            pass
