"""
Home Page Object.
"""

import allure
from pages.base_page import BasePage


class HomePage(BasePage):
    """Home page object containing all home page elements and interactions."""

    # Main CTA buttons
    LEAVE_APPLICATON_BUTTON = lambda self: self.page.get_by_role("button", name="Оставить заявку").first
    LEARN_MORE_BUTTON = lambda self: self.page.get_by_role("button", name="Узнать больше")
    CURRENT_VACANCIES_BUTTON = lambda self: self.page.get_by_role("link", name="Актуальные вакансии")

    # Section headers
    ABOUT_COMPANY_HEADING = lambda self: self.page.get_by_text("О компании")
    COOPERATION_FORMATS_HEADING = lambda self: self.page.get_by_text("Форматы сотрудничества")
    WHO_WE_SEEK_HEADING = lambda self: self.page.get_by_text("Кого мы ищем")
    HOW_IT_WORKS_HEADING = lambda self: self.page.get_by_text("Как это работает")
    WHY_CHOOSE_US_HEADING = lambda self: self.page.get_by_text("Почему выбирают нас")
    REVIEWS_HEADING = lambda self: self.page.get_by_text("Отзывы специалистов")
    CONTACT_US_HEADING = lambda self: self.page.get_by_text("Свяжитесь с нами")

    # Cooperation format buttons
    OUTSTAFFING_OPTION = lambda self: self.page.get_by_role("button", name="Выбрать формат").first
    EMPLOYMENT_HELP_OPTION = lambda self: self.page.get_by_role("button", name="Выбрать формат").last

    # Specialist categories
    IOS_DEVELOPER = lambda self: self.page.get_by_role("heading", name="iOS Developer", level=3).first
    ANDROID_DEVELOPER = lambda self: self.page.get_by_role("heading", name="Android Developer", level=3).first
    BACKEND_DEVELOPER = lambda self: self.page.get_by_role("heading", name="Backend Developer", level=3).first
    QA_ENGINEER = lambda self: self.page.get_by_role("heading", name="QA Engineer", level=3).first
    DEVOPS_ENGINEER = lambda self: self.page.get_by_role("heading", name="DevOps Engineer", level=3).first
    ANALYST = lambda self: self.page.get_by_role("heading", name="Аналитик", level=3)

    # Process steps
    STEP_1_LEAVE_APPLICATION = lambda self: self.page.locator("text=Оставляете заявку")
    STEP_2_INTERVIEW = lambda self: self.page.locator("text=Проходите интервью")
    STEP_3_SELECT_PROJECT = lambda self: self.page.locator("text=Подбираем проект")
    STEP_4_START_WORK = lambda self: self.page.locator("text=Начинаете работу")

    # Contact form fields
    NAME_FIELD = lambda self: self.page.get_by_label("Имя").first
    EMAIL_FIELD = lambda self: self.page.get_by_label("Email").first
    PHONE_FIELD = lambda self: self.page.get_by_label("Телефон")
    SPECIALIZATION_FIELD = lambda self: self.page.get_by_label("Специализация")
    MESSAGE_FIELD = lambda self: self.page.get_by_label("Сообщение")
    SUBMIT_BUTTON = lambda self: self.page.get_by_role("button", name="Отправить заявку")

    @allure.step("Open home page")
    def open_home_page(self):
        """Open the home page."""
        self.open()

    @allure.step("Click Leave Application button")
    def click_leave_application_button(self):
        """Click on 'Оставить заявку' (Leave Application) button."""
        self.click(self.LEAVE_APPLICATON_BUTTON())
        self.page.wait_for_timeout(500)

    @allure.step("Click Learn More button")
    def click_learn_more_button(self):
        """Click on 'Узнать больше' (Learn More) button."""
        self.click(self.LEARN_MORE_BUTTON())

    @allure.step("Click Current Vacancies button")
    def click_current_vacancies_button(self):
        """Click on 'Актуальные вакансии' (Current Vacancies) button."""
        with self.page.context.expect_page() as new_page_info:
            self.click(self.CURRENT_VACANCIES_BUTTON())
        return new_page_info.value

    @allure.step("Verify About Company section is visible")
    def verify_about_company_visible(self):
        """Verify that 'О компании' (About Company) section is visible."""
        self.assert_element_visible(self.ABOUT_COMPANY_HEADING())

    @allure.step("Verify Cooperation Formats section is visible")
    def verify_cooperation_formats_visible(self):
        """Verify that 'Форматы сотрудничества' (Cooperation Formats) section is visible."""
        self.assert_element_visible(self.COOPERATION_FORMATS_HEADING())

    @allure.step("Verify Who We Seek section is visible")
    def verify_who_we_seek_visible(self):
        """Verify that 'Кого мы ищем' (Who We Seek) section is visible."""
        self.scroll_to_element(self.WHO_WE_SEEK_HEADING())
        self.assert_element_visible(self.WHO_WE_SEEK_HEADING())

    @allure.step("Verify How It Works section is visible")
    def verify_how_it_works_visible(self):
        """Verify that 'Как это работает' (How It Works) section is visible."""
        self.scroll_to_element(self.HOW_IT_WORKS_HEADING())
        self.assert_element_visible(self.HOW_IT_WORKS_HEADING())

    @allure.step("Verify Why Choose Us section is visible")
    def verify_why_choose_us_visible(self):
        """Verify that 'Почему выбирают нас' (Why Choose Us) section is visible."""
        self.scroll_to_element(self.WHY_CHOOSE_US_HEADING())
        self.assert_element_visible(self.WHY_CHOOSE_US_HEADING())

    @allure.step("Verify Reviews section is visible")
    def verify_reviews_visible(self):
        """Verify that 'Отзывы специалистов' (Reviews) section is visible."""
        self.scroll_to_element(self.REVIEWS_HEADING())
        self.assert_element_visible(self.REVIEWS_HEADING())

    @allure.step("Verify Contact Us section is visible")
    def verify_contact_us_visible(self):
        """Verify that 'Свяжитесь с нами' (Contact Us) section is visible."""
        self.scroll_to_element(self.CONTACT_US_HEADING())
        self.assert_element_visible(self.CONTACT_US_HEADING())

    @allure.step("Verify iOS Developer specialist category is visible")
    def verify_ios_developer_visible(self):
        """Verify that iOS Developer category is visible."""
        self.scroll_to_element(self.IOS_DEVELOPER())
        self.assert_element_visible(self.IOS_DEVELOPER())

    @allure.step("Verify Android Developer specialist category is visible")
    def verify_android_developer_visible(self):
        """Verify that Android Developer category is visible."""
        self.scroll_to_element(self.ANDROID_DEVELOPER())
        self.assert_element_visible(self.ANDROID_DEVELOPER())

    @allure.step("Verify Backend Developer specialist category is visible")
    def verify_backend_developer_visible(self):
        """Verify that Backend Developer category is visible."""
        self.scroll_to_element(self.BACKEND_DEVELOPER())
        self.assert_element_visible(self.BACKEND_DEVELOPER())

    @allure.step("Verify QA Engineer specialist category is visible")
    def verify_qa_engineer_visible(self):
        """Verify that QA Engineer category is visible."""
        self.scroll_to_element(self.QA_ENGINEER())
        self.assert_element_visible(self.QA_ENGINEER())

    @allure.step("Verify DevOps Engineer specialist category is visible")
    def verify_devops_engineer_visible(self):
        """Verify that DevOps Engineer category is visible."""
        self.scroll_to_element(self.DEVOPS_ENGINEER())
        self.assert_element_visible(self.DEVOPS_ENGINEER())

    @allure.step("Verify Analyst specialist category is visible")
    def verify_analyst_visible(self):
        """Verify that Analyst category is visible."""
        self.scroll_to_element(self.ANALYST())
        self.assert_element_visible(self.ANALYST())

    @allure.step("Verify all process steps are visible")
    def verify_all_process_steps_visible(self):
        """Verify that all process steps are visible."""
        self.assert_element_visible(self.STEP_1_LEAVE_APPLICATION())
        self.assert_element_visible(self.STEP_2_INTERVIEW())
        self.assert_element_visible(self.STEP_3_SELECT_PROJECT())
        self.assert_element_visible(self.STEP_4_START_WORK())

    @allure.step("Fill contact form with data")
    def fill_contact_form(self, name: str, email: str, phone: str = "", specialization: str = "", message: str = ""):
        """Fill the contact form with provided data.
        
        Args:
            name: Full name
            email: Email address
            phone: Phone number (optional)
            specialization: Specialization (optional)
            message: Message (optional)
        """
        self.scroll_to_element(self.CONTACT_US_HEADING())
        self.page.wait_for_timeout(500)
        self.fill(self.NAME_FIELD(), name)
        self.fill(self.EMAIL_FIELD(), email)
        if phone:
            self.fill(self.PHONE_FIELD(), phone)
        if specialization:
            self.fill(self.SPECIALIZATION_FIELD(), specialization)
        if message:
            self.fill(self.MESSAGE_FIELD(), message)

    @allure.step("Submit contact form")
    def submit_contact_form(self):
        """Submit the contact form."""
        self.click(self.SUBMIT_BUTTON())
