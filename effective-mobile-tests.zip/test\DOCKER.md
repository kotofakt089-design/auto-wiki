# Docker для Effective Mobile UI Tests

Запуск тестов в Docker контейнере на локальной машине или удалённом сервере.

## Требования

- Docker
- Docker Compose

## Установка Docker

### Windows

1. Скачайте [Docker Desktop для Windows](https://www.docker.com/products/docker-desktop)
2. Установите и перезагрузитесь
3. Проверьте: `docker --version`

### macOS

```bash
brew install docker docker-compose
```

### Linux

```bash
sudo apt-get install docker.io docker-compose
sudo usermod -aG docker $USER
```

## Запуск тестов в Docker

### Способ 1: Docker Compose (рекомендуется)

```bash
docker-compose up --build
```

Тесты запустятся в контейнере, результаты сохранятся в `reports/`

### Способ 2: Docker вручную

```bash
# Сборка образа
docker build -t effective-mobile-tests .

# Запуск контейнера
docker run -v ./reports:/app/reports effective-mobile-tests
```

## Просмотр результатов

Результаты HTML отчёта:
```bash
reports/report.html
```

## Команды Docker

```bash
# Просмотр образов
docker images

# Просмотр контейнеров
docker ps -a

# Удалить образ
docker rmi effective-mobile-tests

# Остановить контейнер
docker stop <container_id>

# Удалить контейнер
docker rm <container_id>
```

## Преимущества Docker

✓ Одинаковая среда везде (Windows/macOS/Linux)
✓ Не нужно устанавливать Python локально
✓ Все зависимости изолированы
✓ Простой запуск на удалённых машинах
✓ CI/CD интеграция

## Troubleshooting

### Docker не запускается

```bash
docker version
```

Если ошибка — переустановите Docker Desktop.

### Нет прав на запуск Docker (Linux)

```bash
sudo usermod -aG docker $USER
newgrp docker
```

### Контейнер падает с ошибкой

```bash
docker logs <container_id>
```

### Очистить всё

```bash
docker-compose down -v
docker system prune -a
```

## Примеры использования

### Запуск только Header тестов

```bash
docker run effective-mobile-tests python -m pytest tests/ui/test_header.py -v
```

### Запуск с видимым браузером (локально)

```bash
docker run -e HEADLESS=false effective-mobile-tests
```

## Production использование

На удалённом сервере:

```bash
# Клонируйте проект
git clone https://github.com/yourusername/effective-mobile-tests.git
cd effective-mobile-tests

# Запустите
docker-compose up --build

# Результаты будут в ./reports/
```
