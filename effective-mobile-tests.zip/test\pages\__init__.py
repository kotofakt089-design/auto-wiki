"""
Pages package initialization.
"""

from pages.base_page import BasePage
from pages.home_page import HomePage
from pages.header import Header
from pages.footer import Footer

__all__ = [
    "BasePage",
    "HomePage",
    "Header",
    "Footer",
]
