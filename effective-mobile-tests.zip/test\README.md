# Effective Mobile UI Tests

Автоматизированные UI тесты для https://www.effective-mobile.ru/

## Описание

37 функциональных тестов на Python используя Playwright и pytest.

## Содержимое

- tests/ui/ - 37 тестов (Header, Home Page, Footer)
- pages/ - 4 Page Objects
- conftest.py - конфигурация pytest
- pytest.ini - параметры тестирования
- requirements.txt - зависимости Python

## Требования

- Python 3.10 или выше
- pip

## Установка и запуск

### 1. Установите зависимости

Windows:
```bash
python -m pip install -r requirements.txt
```

macOS/Linux:
```bash
python3 -m pip install -r requirements.txt
```

### 2. Установите браузер Playwright

Windows:
```bash
python -m playwright install chromium
```

macOS/Linux:
```bash
python3 -m playwright install chromium
```

### 3. Запустите тесты

Windows:
```bash
python -m pytest tests/ui/ -v
```

macOS/Linux:
```bash
python3 -m pytest tests/ui/ -v
```

## Результат

Вывод должен быть:
```
collected 37 items
tests\ui\test_footer.py .........
tests\ui\test_header.py .........
tests\ui\test_home.py ...................
============================= 37 passed in ~55s =============================
```

## Команды запуска

Все тесты:
```bash
python -m pytest tests/ui/ -v
```

Только Header:
```bash
python -m pytest tests/ui/test_header.py -v
```

Только Home Page:
```bash
python -m pytest tests/ui/test_home.py -v
```

Только Footer:
```bash
python -m pytest tests/ui/test_footer.py -v
```

Один конкретный тест:
```bash
python -m pytest tests/ui/test_header.py::TestHeader::test_about_link_visible -v
```

С видимым браузером:
```bash
HEADLESS=false python -m pytest tests/ui/ -v -s
```

С HTML отчетом:
```bash
python -m pytest tests/ui/ -v --html=reports/report.html --self-contained-html
```

## Структура проекта

```
.
├── tests/
│   └── ui/
│       ├── test_header.py        (9 тестов)
│       ├── test_home.py          (19 тестов)
│       └── test_footer.py        (9 тестов)
├── pages/
│   ├── base_page.py              (базовый класс)
│   ├── header.py                 (навигация)
│   ├── home_page.py              (главная страница)
│   └── footer.py                 (подвал)
├── conftest.py                   (конфигурация pytest)
├── pytest.ini                    (параметры)
├── requirements.txt              (зависимости)
└── README.md                     (этот файл)
```

## Решение проблем

### Python не найден

Убедитесь что Python установлен и добавлен в PATH:
```bash
python --version
```

### Модули не установлены

Переустановите зависимости:
```bash
pip install -r requirements.txt
```

### Браузер не установлен

Установите Playwright:
```bash
python -m playwright install chromium
```

### Тесты падают на timeout

Увеличьте timeout в conftest.py строке с браузером.

## Версия

Версия: 1.0
Дата: 17 ноября 2025
